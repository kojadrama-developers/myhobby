create trigger user_before_delete
  before DELETE
  on users
  for each row
  BEGIN
SET @changetype = 'DELETE';
INSERT INTO audit(user_id, changetype,changetime) VALUES(OLD.user_id, @changetype,now());
END;

