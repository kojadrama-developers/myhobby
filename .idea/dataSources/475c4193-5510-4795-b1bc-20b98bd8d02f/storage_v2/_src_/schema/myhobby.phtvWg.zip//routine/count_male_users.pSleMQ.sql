create procedure count_male_users()
  BEGIN
SELECT COUNT(user_id) AS 'Number of male users' FROM users_info
WHERE sex='Male';
END;

