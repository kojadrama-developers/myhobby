create function calculate_user_age(ID int)
  returns text
  BEGIN
DECLARE cur_year DATE;
DECLARE user_year INT(10);
DECLARE gender VARCHAR(10);
DECLARE age INT;
DECLARE msg VARCHAR(255);
SET cur_year=(SELECT date_of_birth FROM users_info WHERE user_id=ID);
SET user_year=YEAR(cur_year);
SET gender=(SELECT sex FROM users_info WHERE user_id=ID);
SET age=YEAR(CURRENT_DATE)-user_year;
IF (age<30 AND gender='Male') THEN 
SET msg=CONCAT('Hello young man, your age is ',age,'.');
ELSEIF (age<30 AND gender='Female') THEN 
SET msg=CONCAT('Hello young lady, your age is ',age,'.');
ELSEIF (age>=30 AND gender='Male') THEN 
SET msg=CONCAT('Hello gentleman, your age is ',age,'.');
ELSEIF (age>=30 AND gender='Female') THEN 
SET msg=CONCAT('Hello lady, your age is ',age,'.');
ELSE
SET msg=CONCAT('Hello stranger, your age is ',age,'.');
END IF;
RETURN msg;
END;

