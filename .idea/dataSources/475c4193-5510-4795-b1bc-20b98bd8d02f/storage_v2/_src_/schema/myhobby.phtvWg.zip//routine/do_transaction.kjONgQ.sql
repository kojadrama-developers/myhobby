create procedure do_transaction(IN take_id int, IN give_id int, IN amount double, OUT message varchar(255))
  BEGIN 
DECLARE current_amount DOUBLE(10,2) DEFAULT 0;
BEGIN
DECLARE EXIT HANDLER for not found
SET message=' No user was found with this id!';
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
SET message='Error';
END;
START TRANSACTION;
SELECT money_amount INTO current_amount FROM user_money WHERE user_id=take_id;
IF current_amount > amount THEN
UPDATE user_money SET money_amount = money_amount - amount WHERE user_id=take_id;
UPDATE user_money SET money_amount = money_amount + amount WHERE user_id=give_id;
ELSE
SET message="User doesn't have enough money!";
END IF;
END;
IF message!='' THEN
ROLLBACK;
ELSE 
COMMIT;
SET message='SUCCESS';
END IF;
END;

