create function find_oldest_and_youngest()
  returns text
  BEGIN
DECLARE oldest_date DATE;
DECLARE youngest_date DATE;
DECLARE f_oldest_user VARCHAR(100);
DECLARE f_youngest_user VARCHAR(100);
DECLARE l_oldest_user VARCHAR(100);
DECLARE l_youngest_user VARCHAR(100);
DECLARE age1 VARCHAR(255);
DECLARE age2 VARCHAR(255);
SET oldest_date=(SELECT date_of_birth FROM users_info ORDER BY date_of_birth ASC LIMIT 1);
SET youngest_date=(SELECT date_of_birth FROM users_info ORDER BY date_of_birth DESC LIMIT 1);
SET f_oldest_user=(SELECT first_name FROM users_info ORDER BY date_of_birth ASC LIMIT 1);
SET f_youngest_user=(SELECT first_name FROM users_info ORDER BY date_of_birth DESC LIMIT 1);
SET l_oldest_user=(SELECT last_name FROM users_info ORDER BY date_of_birth ASC LIMIT 1);
SET l_youngest_user=(SELECT last_name FROM users_info ORDER BY date_of_birth DESC LIMIT 1);
SET age1=(YEAR(CURRENT_DATE)-YEAR(oldest_date));
SET age2=(YEAR(CURRENT_DATE)-YEAR(youngest_date));
RETURN CONCAT('Our oldest user is ',f_oldest_user,' ',l_oldest_user,' (',age1,')',' and our youngest user is ',f_youngest_user,' ',l_youngest_user,' (',age2,').');
END;

