create trigger user_after_insert
  after INSERT
  on users
  for each row
  BEGIN
IF NEW.deleted THEN
	SET @changetype = 'DELETE';
    ELSE
    SET @changetype = 'NEW';
    END IF;
    
    INSERT INTO audit (user_id, changetype,changetime) VALUES (NEW.user_id, @changetype,now());
    END;

