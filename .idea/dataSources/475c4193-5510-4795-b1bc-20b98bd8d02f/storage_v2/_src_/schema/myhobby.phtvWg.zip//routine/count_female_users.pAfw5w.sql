create procedure count_female_users()
  BEGIN
SELECT COUNT(user_id) AS 'Number of female users' FROM users_info
WHERE sex='Female';
END;

