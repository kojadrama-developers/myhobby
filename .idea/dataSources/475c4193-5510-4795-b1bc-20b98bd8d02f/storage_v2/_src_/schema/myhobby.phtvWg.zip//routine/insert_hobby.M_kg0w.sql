create procedure insert_hobby(IN cat_id int, IN num_of_hobbies int, OUT message varchar(255), IN your_id int)
  BEGIN
DECLARE counter INT DEFAULT 0;
DECLARE current_amount DOUBLE(10,2) DEFAULT 0;
DECLARE EXIT HANDLER FOR NOT FOUND
SET message='User was not found';
DECLARE EXIT HANDLER FOR SQLEXCEPTION
BEGIN
ROLLBACK;
SET message='Error';
END;
START TRANSACTION;
WHILE counter < num_of_hobbies
DO
SET counter=counter+1;
INSERT INTO sub_category(category_id,sub_category_name) VALUES (cat_id,CONCAT('Hobby number ',counter));
END WHILE;
SELECT money_amount INTO current_amount FROM user_money WHERE user_id=your_id;
UPDATE user_money SET money_amount=money_amount + (counter*10) WHERE user_id=your_id;
IF message!='' THEN
ROLLBACK;
ELSE 
COMMIT;
SET message=CONCAT('Number of inserted hobbies is ', counter,'. We added ', counter*10,' NRKĆcash to your account!');
END IF;
END;

