create view state as
  select
    `myhobby`.`users_info`.`first_name` AS `First name`,
    `myhobby`.`users_info`.`last_name`  AS `Last name`
  from `myhobby`.`users_info`
  where (`myhobby`.`users_info`.`state` = 'Serbia');

