create procedure register_user(IN  user_email     varchar(255), IN user_password varchar(255),
                               OUT user_message   varchar(255), IN user_first_name varchar(100),
                               IN  user_last_name varchar(100), IN user_date_of_birth date, IN user_sex varchar(10),
                               IN  user_state     varchar(255))
  BEGIN
DECLARE check_email VARCHAR(255);
DECLARE id INT;
SET check_email=(SELECT email FROM users WHERE email=user_email);

IF(check_email=user_email) THEN
SET user_message="User with this email already exists!";
ELSE

INSERT INTO users(`email`,`password`) VALUES (`user_email`,`user_password`);
SET id=(SELECT `user_id` FROM users ORDER BY `user_id` DESC LIMIT 1);
INSERT INTO users_info (`user_id`,`first_name`,`last_name`,`date_of_birth`,`sex`,`state`) VALUES (`id`,`user_first_name`,`user_last_name`,`user_date_of_birth`,`user_sex`,`user_state`);
INSERT INTO user_money(`user_id`,`money_amount`) VALUES (`id`,100);
SET user_message="User registered";

END IF;

END;

