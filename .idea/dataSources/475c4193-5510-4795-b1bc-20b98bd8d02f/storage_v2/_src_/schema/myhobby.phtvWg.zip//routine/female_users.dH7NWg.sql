create procedure female_users()
  BEGIN
SELECT users_info.first_name as 'First name', users_info.last_name as 'Last name', users.email FROM users_info
JOIN users ON users_info.user_id=users.user_id
WHERE sex='Female';
END;

