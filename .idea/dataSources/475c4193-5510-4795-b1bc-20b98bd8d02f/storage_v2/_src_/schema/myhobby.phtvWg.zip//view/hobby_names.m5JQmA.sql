create view hobby_names as
  select `myhobby`.`sub_category`.`sub_category_name` AS `Svi hobiji iz prve kategorije`
  from `myhobby`.`sub_category`
  where (`myhobby`.`sub_category`.`category_id` = 1);

